# Supportive Therapy Network — Flutter MVP scaffold

This is a development scaffold for synthetic-data testing only. It is not a validated diagnostic instrument or a production clinical record.

## Run locally
1. Install a current stable Flutter SDK.
2. Extract this pack and enter `supportive_therapy_network_mvp/`.
3. Run `flutter create --platforms=web .` if web platform files are absent.
4. Run `flutter pub get`, `dart format .`, `flutter analyze`, `flutter test`, and `flutter build web`.

## Current limits
- The included MDD items and severity sum are illustrative, not a validated or licensed instrument score.
- Any positive designated safety item or incomplete assessment prompts clinician review; this is not crisis triage or proof of safety.
- Data remains in memory only. There is no authentication, secure persistence, audit trail, clinical integration, or production safety escalation service.
- Use synthetic data only. Do not use for diagnosis, triage, emergency disposition, treatment decisions, or real-client records.
