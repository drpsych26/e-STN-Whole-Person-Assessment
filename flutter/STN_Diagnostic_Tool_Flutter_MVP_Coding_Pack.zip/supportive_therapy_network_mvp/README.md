# Supportive Therapy Network – Diagnostic Tool (Flutter MVP)

## What this is
An offline-first Flutter scaffold for the STN Diagnostic Tool:
- Home screen listing modules
- MDD module UI
- Scoring + risk-flag logic
- Results dialog

## How to run (developer steps)
1) Install Flutter (https://flutter.dev/docs/get-started/install)
2) Create a new Flutter project (one time):
   flutter create supportive_therapy_network
3) Replace the generated project's files with the contents of this pack (same paths).
4) Get dependencies:
   flutter pub get
5) Run:
   flutter run

## Notes
- This MVP stores responses in memory only. Next step is adding encrypted local storage and export/report generation.
