import "package:flutter/material.dart";
import "screens/home_screen.dart";

void main() {
  runApp(const STNApp());
}

class STNApp extends StatelessWidget {
  const STNApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Supportive Therapy Network",
      theme: ThemeData(useMaterial3: true),
      home: const HomeScreen(),
    );
  }
}
