import "package:flutter/material.dart";
import "mdd_screen.dart";

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("STN Diagnostic Tool")),
      body: ListView(
        children: [
          ListTile(
            title: const Text("Major Depressive Disorder (MDD)"),
            subtitle: const Text("Severity + risk flagging"),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const MddScreen()),
            ),
          ),
        ],
      ),
    );
  }
}
