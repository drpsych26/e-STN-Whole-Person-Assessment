import "package:flutter/material.dart";
import "../models/assessment_models.dart";
import "../modules/mdd_module.dart";
import "../logic/scoring_engine.dart";

class MddScreen extends StatefulWidget {
  const MddScreen({super.key});

  @override
  State<MddScreen> createState() => _MddScreenState();
}

class _MddScreenState extends State<MddScreen> {
  final Map<String, Severity> _responses = {};
  final _engine = ScoringEngine();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("MDD Module")),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text("Rate each item (0–4): 0 None, 1 Mild, 2 Moderate, 3 Severe, 4 Extreme."),
          const SizedBox(height: 12),
          ...mddQuestions.map((q) => _questionTile(q)),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: _responses.length < mddQuestions.length ? null : _score,
            child: const Text("Score Module"),
          ),
        ],
      ),
    );
  }

  Widget _questionTile(Question q) {
    final current = _responses[q.id];
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(q.text, style: const TextStyle(fontWeight: FontWeight.w600)),
            if (q.isRiskItem)
              const Padding(
                padding: EdgeInsets.only(top: 6),
                child: Text("Risk item", style: TextStyle(fontSize: 12)),
              ),
            DropdownButton<Severity>(
              value: current,
              hint: const Text("Select severity"),
              isExpanded: true,
              items: Severity.values.map((s) {
                return DropdownMenuItem(
                  value: s,
                  child: Text(s.name),
                );
              }).toList(),
              onChanged: (v) => setState(() => _responses[q.id] = v!),
            ),
          ],
        ),
      ),
    );
  }

  void _score() {
    final answers = _responses.entries
        .map((e) => Answer(questionId: e.key, severity: e.value))
        .toList();

    final result = _engine.score("MDD", mddQuestions, answers);

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("MDD Result"),
        content: Text(
          "Total Score: ${result.totalScore}\n"
          "Clinician Review Required: ${result.riskFlag ? "YES" : "NO"}\n\n"
          "${result.interpretation}",
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Close")),
        ],
      ),
    );
  }
}
