import "../models/assessment_models.dart";

int severityToScore(Severity s) {
  switch (s) {
    case Severity.none:
      return 0;
    case Severity.mild:
      return 1;
    case Severity.moderate:
      return 2;
    case Severity.severe:
      return 3;
    case Severity.extreme:
      return 4;
  }
}

class ScoringEngine {
  ModuleResult scoreMdd(List<Answer> answers) {
    final total = answers.fold<int>(0, (sum, a) => sum + severityToScore(a.severity));

    // Risk flag: any suicidal ideation item >= Moderate triggers risk
    final risk = answers.any((a) =>
        a.questionId == "mdd_q9_suicide" &&
        (a.severity == Severity.moderate ||
            a.severity == Severity.severe ||
            a.severity == Severity.extreme));

    final interpretation = _interpretMdd(total, risk);

    return ModuleResult(
      moduleId: "MDD",
      totalScore: total,
      interpretation: interpretation,
      riskFlag: risk,
    );
  }

  String _interpretMdd(int totalScore, bool riskFlag) {
    // Cut-offs are configurable. Refine clinically to your preferred standard.
    if (riskFlag) return "High priority: suicide risk flag triggered. Immediate risk assessment required.";
    if (totalScore >= 28) return "Severe depressive symptom burden (provisional).";
    if (totalScore >= 18) return "Moderate depressive symptom burden (provisional).";
    if (totalScore >= 8) return "Mild depressive symptom burden (provisional).";
    return "Minimal depressive symptom burden (provisional).";
  }
}
