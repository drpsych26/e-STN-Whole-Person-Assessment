import "../models/assessment_models.dart";

/// Conservative interim scoring for an unvalidated prototype.
/// A response sum is descriptive only; it is not a diagnostic score.
int severityToScore(Severity severity) {
  switch (severity) {
    case Severity.none: return 0;
    case Severity.mild: return 1;
    case Severity.moderate: return 2;
    case Severity.severe: return 3;
    case Severity.extreme: return 4;
  }
}

class ScoringEngine {
  ModuleResult score(String moduleId, List<Question> questions, List<Answer> answers) {
    if (questions.isEmpty) {
      throw ArgumentError('Unknown or unconfigured assessment module: $moduleId');
    }

    final questionIds = questions.map((question) => question.id).toSet();
    if (questionIds.length != questions.length) {
      throw ArgumentError('Question IDs must be unique within a module.');
    }
    final seen = <String>{};
    for (final answer in answers) {
      if (!questionIds.contains(answer.questionId)) {
        throw ArgumentError('Unknown question ID: ${answer.questionId}');
      }
      if (!seen.add(answer.questionId)) {
        throw ArgumentError('Duplicate answer for question: ${answer.questionId}');
      }
    }

    final itemScores = <String, int>{};
    for (final answer in answers) {
      itemScores[answer.questionId] = severityToScore(answer.severity);
    }
    final total = itemScores.values.fold<int>(0, (sum, value) => sum + value);
    final incomplete = questions.any((question) => !seen.contains(question.id));
    final safetyReviewRequired = incomplete || questions.any((question) {
      if (!question.isRiskItem) return false;
      final answer = answers.where((a) => a.questionId == question.id).firstOrNull;
      return answer == null || answer.severity != Severity.none;
    });

    final interpretation = (safetyReviewRequired
        ? 'Clinician review required: assessment is incomplete and/or a designated safety-review item is positive or unanswered. This flag is not a risk assessment or crisis disposition. '
        : 'No review flag triggered by this interim rule set; this is not proof of safety. ') +
        'The response-severity sum is descriptive only, not a validated instrument score or diagnosis. Diagnostic criteria are not assessed.';

    return ModuleResult(
      moduleId: moduleId,
      totalScore: total,
      interpretation: interpretation,
      riskFlag: safetyReviewRequired,
      criteriaMet: false,
      completedAt: DateTime.now(),
      itemScores: itemScores,
    );
  }
}
