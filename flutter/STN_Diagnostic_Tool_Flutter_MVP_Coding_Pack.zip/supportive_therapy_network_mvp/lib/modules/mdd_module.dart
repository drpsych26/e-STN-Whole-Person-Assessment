import "../models/assessment_models.dart";

final mddQuestions = <Question>[
  Question(id: "mdd_q1_mood", text: "Depressed mood most of the day, nearly every day."),
  Question(id: "mdd_q2_interest", text: "Markedly diminished interest or pleasure in activities."),
  Question(id: "mdd_q3_weight", text: "Significant weight change or appetite disturbance."),
  Question(id: "mdd_q4_sleep", text: "Insomnia or hypersomnia."),
  Question(id: "mdd_q5_psychomotor", text: "Psychomotor agitation or retardation."),
  Question(id: "mdd_q6_fatigue", text: "Fatigue or loss of energy."),
  Question(id: "mdd_q7_guilt", text: "Feelings of worthlessness or excessive guilt."),
  Question(id: "mdd_q8_concentration", text: "Diminished ability to think or concentrate."),
  Question(id: "mdd_q9_suicide", text: "Recurrent thoughts of death or self-harm.", isRiskItem: true),
];
