class ClientProfile {
  final String id;
  final String fullName;
  final DateTime dob;

  ClientProfile({required this.id, required this.fullName, required this.dob});
}

enum Severity { none, mild, moderate, severe, extreme }

class Question {
  final String id;
  final String text;
  final bool isRiskItem;

  Question({required this.id, required this.text, this.isRiskItem = false});
}

class Answer {
  final String questionId;
  final Severity severity;

  Answer({required this.questionId, required this.severity});
}

class ModuleResult {
  final String moduleId;
  final int totalScore;
  final String interpretation;
  final bool riskFlag;
  final bool criteriaMet;
  final DateTime completedAt;
  final Map<String, int> itemScores;

  ModuleResult({
    required this.moduleId,
    required this.totalScore,
    required this.interpretation,
    required this.riskFlag,
    required this.criteriaMet,
    required this.completedAt,
    required this.itemScores,
  });
}
